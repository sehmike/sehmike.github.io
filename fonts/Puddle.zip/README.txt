PUDDLE
A melting sans-serif by Michael Seh. Built on Source Sans 3.


INSTALLATION

  Windows:
    Right-click Puddle.ttf > Install
    or drag into Settings > Personalization > Fonts

  Mac:
    Double-click Puddle.ttf > Install Font
    or drag into Font Book

  Web:
    @font-face {
      font-family: 'Puddle';
      src: url('Puddle.ttf') format('truetype');
    }


CREDITS

  Base font:  Source Sans 3 by Adobe
  Design:     Michael Seh (michaelseh.com)


LICENSE

  SIL Open Font License, Version 1.1
  See LICENSE.txt for full text.