IKON REGULAR v7
Font by Michael Seh
Copyright 2026 Michael Seh

================================================================
WHAT'S INCLUDED
================================================================

  windows/Ikon-Regular.ttf    Desktop font for Windows
  windows/Ikon-Regular.woff   Web font for Windows builds
  macos/Ikon-Regular.ttf      Desktop font for macOS
  macos/Ikon-Regular.woff     Web font for macOS builds
  Ikon-character-map.jpg      Full character map reference
  Ikon-design-dna.jpg         Design DNA and feature overview
  Ikon-hierarchy.jpg          Type hierarchy specimen

================================================================
INSTALL INSTRUCTIONS
================================================================

WINDOWS (10/11)
  1. Open the "windows" folder
  2. Right-click "Ikon-Regular.ttf"
  3. Select "Install" or "Install for all users"
  4. The font will appear as "Ikon" in your applications

  To uninstall:
  - Open Settings > Personalization > Fonts
  - Search for "Ikon", click it, then click "Uninstall"

macOS
  1. Open the "macos" folder
  2. Double-click "Ikon-Regular.ttf"
  3. Font Book will open with a preview
  4. Click "Install Font"
  5. The font will appear as "Ikon" in your applications

  To uninstall:
  - Open Font Book (Applications > Font Book)
  - Find "Ikon", right-click, and select "Remove"

WEB USE (WOFF)
  Use the .woff file in your CSS:

  @font-face {
      font-family: 'Ikon';
      src: url('Ikon-Regular.woff') format('woff');
      font-weight: normal;
      font-style: normal;
  }

================================================================
FONT METADATA
================================================================

  Family Name:    Ikon
  Style:          Regular
  Version:        7.0
  PostScript:     Ikon-Regular
  Units Per Em:   1000
  Cap Height:     750
  Kern Pairs:     2,515

================================================================
v7 CHANGES
================================================================

  - Tightened kerning on f+o, F+o, and P+o pairs
  - Updated all version metadata from v6 to v7
  - Regenerated reference images with corrected data

================================================================

For questions or licensing, contact Michael Seh.